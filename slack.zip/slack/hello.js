$(document).ready(function() {
    $.ajax({
        url: "https://severurl/salescomms/customers/customers/2"
    }).then(function(data) {
        $('.custid').append(data.custid);
        $('.customer').append(data.customer);
    });
});
