var url = "https://hooks.slack.com/services/TRS13D7MG/webhook";
var text = "hello i am testing";
$.ajax({
    data: 'payload=' + JSON.stringify({
        "text": text
    }),
    dataType: 'json',
    processData: false,
    type: 'POST',
    url: url
});
