<?php

/*
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
*/


$slack_webhook_url = "https://hooks.slack.com/services/webhook";
$text = $_REQUEST['text'];
require_once '../vendor/autoload.php';
require 'slackphp/slack.php';

include '../php/Classes/elasticimpl.php';
$ElasticImplObj = new ElasticImpl;

include '../php/Classes/template2.php';
$TemplateObj = new Template2;

$client = Elasticsearch\ClientBuilder::create()->setHosts(['el-search-server:9200'])->build(); // NEW VM
//$client = Elasticsearch\ClientBuilder::create()->setHosts(['132.145.223.48:9200'])->build(); // OLD VM

if(isset($_REQUEST['text']))
{
    $q = $_REQUEST['text'];
    $tag = "'Title', 'Description','Info','class'";
    // Use the url you got earlier

    $elArr = $ElasticImplObj->getElSearchResultsandSort($q, $tag, $client);
    $hits = $elArr['hits'];
    $result = $elArr['result'];
    $idarr = $elArr['idarr'];

    if ($hits > 0)
    {
        $slack = new Slack('https://hooks.slack.com/services/T7XFK7R1A/webhook');
        $slack->setDefaultUsername("CommsApp ");
        $message = new SlackMessage($slack);
        $attachment = new SlackAttachment("Slack Search !");
        $attachment->setColor("#36a64f");
        $attachment->setPretext("Search engine");
        $attachment->setImage(":mag_right:");

        foreach ($result as $key => $value)
        {
            $title = $value['Title'];
            $description = $value['Description'];
            $info = $value['Info'];
            $image = $value['Image'];
            $Info_CTA_URL = $value['Info_CTA_URL'];
            $Link_URL = $value['Link_URL'];
            if ($description != "") {
                $description = strip_tags($description);
                $attachment->addField("$title", "$description");
            }
            if ($info != "") {
                $info = strip_tags($info);
                $attachment->addField("Details: ", "$info");
            }
            if ($Info_CTA_URL != "") {
                //$Info_CTA_URL = strip_tags($Info_CTA_URL);
                //$attachment->addField("more info: ", "$Info_CTA_URL");
                $attachment->addButton("more info", $Info_CTA_URL, null);
            }
            if ($Link_URL != "") {
                //$Info_CTA_URL = strip_tags($Info_CTA_URL);
                //$attachment->addField("more info: ", "$Info_CTA_URL");
                $attachment->addButton("more info", $Link_URL, null);
            }
        }
    }

}

$attachment->setTimestamp(time());

// Add it to your message
$message->addAttachment($attachment);

// Send
$message->send();
